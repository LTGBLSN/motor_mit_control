#ifndef __LED_H
#define __LED_H

#include "stm32F0xx_hal.h"

void LED_RUN(void);
void LED_CAN(void);

#endif
