
#ifndef __MCU_CONFIG_H__
#define __MCU_CONFIG_H__
#include "main.h"



void MCU_Init(void);


#endif


