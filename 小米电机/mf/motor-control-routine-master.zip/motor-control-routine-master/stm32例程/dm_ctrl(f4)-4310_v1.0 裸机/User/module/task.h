#ifndef __TASK_H__
#define __TASK_H__

void task_init(void);
void task_1ms(void);
void task_2ms(void);
void task_5ms(void);
void task_10ms(void);
void task_100ms(void);
void task_500ms(void);

#endif /* __TASK_H__ */

