# DM_USB2CAN C#例程

#### 介绍
1. 封装了 DM 的 USB2CAN 模块收发的dll库 ———— DM_USB2CAN.dll
2. 发送协议相关的参见 DM CAN控制相关协议格式.xlsx 和 USB to CAN.xlsx
3. 有关官方例程写在 Form1.cs 中

#### 使用说明

1.  c# 项目中添加引用，选择 DM_USB2CAN.dll
2.  参考控制协议以及官方例程进行开发
